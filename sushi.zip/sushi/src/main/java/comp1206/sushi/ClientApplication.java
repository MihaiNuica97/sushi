package comp1206.sushi;

public class ClientApplication {
	public static void main(String[] argv) {
		
	}
}
